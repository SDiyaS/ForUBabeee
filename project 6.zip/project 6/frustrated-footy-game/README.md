# Frustrated Footy For U Babe 🐥

A fun football penalty game with 5 special messages to unlock!

## How to Play

1. Open `index.html` in any web browser
2. Click and drag from the ball to aim your shot
3. Release to shoot the ball toward the goal
4. Score all 5 goals consecutively to unlock all messages
5. If you miss any shot, you start over from the beginning!

## Features

- Beautiful football field graphics
- Realistic ball physics with trajectory prediction
- Animated goalkeeper
- 5 special personal messages to unlock
- Mobile-friendly touch controls
- Celebration animations

## Installation

Simply download all files and open `index.html` in your web browser. No additional setup required!

## Files Included

- `index.html` - Main game page
- `styles.css` - Game styling and animations
- `game.js` - Game logic and physics
- `README.md` - This file

Enjoy the game! 🎮⚽